/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Character.h
 * Author: Admin
 *
 * Created on February 20, 2019, 2:36 PM
 */

#ifndef CHARACTER_H
#define CHARACTER_H
using namespace std;
class Character {
protected:
    string c_name;
    string c_size;
    double c_weight;
    int c_speed;
    double c_hair;
    string c_race;
public:
    Character(string name, string size, double weight, int speed, double hair, string race) {
        c_name = name;
        c_size = size;
        c_weight = weight;
        c_speed = speed;
        c_hair = hair;
        c_race = race;
    }   
    void print() const {
        cout << left;
        cout << setw(20) << "Name: " + c_name;
        cout << setw(15) << "Size: " + c_size;
        cout << setw(20) << "Weight: " + to_string(c_weight);
        cout << setw(20) << "Speed: " + to_string(c_speed);
        cout << setw(20) << "HairLen: " + to_string(c_hair);
        cout << setw(20) << "Race: " + c_race;
        cout << setw(20) << getSpecial();
    }
    virtual string getSpecial() const = 0;
    string getName() const {
      return c_name;  
    } 
    string getRace() const {
       return c_race; 
    }
    int getHair() const {
       return c_hair;
    }
    string getSpeed() const {
        return c_speed;
    }
    
};

class Small : public Character {
protected:
    bool c_equip;
public:
    virtual string getSpecial() const {
        if (c_equip == true) {
            return "IsEquipped: 1";
        }
        return "IsEquipped: 0";
    }
    void setEquipped(bool equip) {
        c_equip = equip;
    }
};

class Medium : public Character {
protected:
    string c_weapon;
public:
    virtual string getSpecial() const {
        return "Weapon: " + c_weapon;
    }
    void setWeapon(string weapon) {
        c_weapon = weapon;
    }
};

class Big : public Character {
protected:
    string c_skill;
public:
    virtual string getSpecial() const {
        return "Skill: " + c_skill;
    }
    void setSkill(string skill) {
        c_skill = skill;
    }
};

#endif /* CHARACTER_H */

