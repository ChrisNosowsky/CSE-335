/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CharacterFactory.h
 * Author: Admin
 *
 * Created on February 20, 2019, 2:36 PM
 */

#ifndef CHARACTERFACTORY_H
#define CHARACTERFACTORY_H
#include <iostream>
#include <string>
using namespace std;

string remove_space(string s){
    for(int i = 0; i < s.length(); i++){
        if(isalnum(s[i])){
            return s[i:];
        }
    }
    return "";
}
class CharacterFactory {
public:
    virtual Character* createCharacter(string s) const = 0;
};

class BigCreate : public CharacterFactory {
public:
    virtual Character* createCharacter(string s) const {
        string delimiter = " ";
        string name = s.substr(0, s.find(delimiter));
        
        s = remove_space(s[name.length():]);
        string size = s.substr(0,s.find(delimiter));
        
        s = remove_space(s[size.length():]);
        double weight = stod(s.substr(0,s.find(delimiter)));
        
        s = remove_space(s[to_string(weight).length():]);
        int speed = stoi(s.substr(0,s.find(delimiter)));
        
        s = remove_space(s[to_string(speed).length():]);
        double hairlen = stod(s.substr(0,s.find(delimiter))); 
       
        s = remove_space(s[to_string(hairlen).length():]);
        string race = s.substr(0,s.find(delimiter));
        
        s = remove_space(s[race.length():]);
        string skill = s;
        
        
        
        
        
    }
};
class MedCreate : public CharacterFactory {
public:
    virtual Character* createCharacter(string s) const {
        
    }
};
class SmallCreate : public CharacterFactory {
public:
    virtual Character* createCharacter(string s) const {
        
    }
};
#endif /* CHARACTERFACTORY_H */

