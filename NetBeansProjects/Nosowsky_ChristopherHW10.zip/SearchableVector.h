/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SearchableVector.h
 * Author: Admin
 *
 * Created on February 17, 2019, 3:38 PM
 */

#ifndef SEARCHABLEVECTOR_H
#define SEARCHABLEVECTOR_H
using namespace std;
class SearchableVector {
public:
    int size = 0;
    int query;
protected:
    SearchableVector() {
        
    }
    
};

#endif /* SEARCHABLEVECTOR_H */

